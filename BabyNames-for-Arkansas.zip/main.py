#babynames for Arkansas
def read_file_as_list(filename):
    file_in = open(filename)
    contents = file_in.readlines()
    file_in.close()
    return contents

def find_most_popular_babyname(filename, year, gender):
    #call read_file_as_list
    lines = read_file_as_list(filename)
    #use a for each loop to split the data up "WA,F,2009,Isabella,203"
    for line in lines:
        # use the strip() method to trim off any whitespace/newlines before split
        items = line.strip().split(',')
        # if the gender and are the same as the ones passed in  
        if(items[1]==gender) and (items[2]==year):
            return items #"WA,F,2009,Isabella,203"
    
# get input from user
gender = input("Enter the gender(F or M) for the most popular name to search for: ")
year = input("Enter a year from 1910 to 2017: ")

#call find_most_popular_babyname
       
items = find_most_popular_babyname('AK.TXT',year,gender)
print("Arkansas: Most popular baby name is,"+items[3]+",for year "+items[2]+". The frequency at which the name occured is:"+items[4]+".")
