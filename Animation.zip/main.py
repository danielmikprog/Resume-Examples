import turtle
import math
import random
my_turtle= turtle.Turtle()
my_turtle.speed(0)

red = random.randint(0,255)
green = random.randint(0,255)
blue = random.randint(0,255)
my_turtle.pencolor(red,green,blue)

screen_obj=turtle.Screen()
screen_obj.bgcolor(red,green,blue)


def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(0,100)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)

        

my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(100,0)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(-100,0)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(0,-100)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(0,0)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(-50,50)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(-50,-50)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()
def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(50,50)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()

def circle():
    my_turtle= turtle.Turtle()
    branches = 20
    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)
    
    my_turtle= turtle.Turtle()
    branches= 20
    length=my_turtle.forward(50)
    backup=my_turtle.backward(30)


    my_turtle.up()
    my_turtle.goto(50,-50)
    my_turtle.down()

    red = random.randint(0,255)
    green = random.randint(0,255)
    blue = random.randint(0,255)
    my_turtle.pencolor(red,green,blue)
    my_turtle.pensize(1)


    for count in range(0,branches):
        my_turtle.forward(50)
        my_turtle.backward(30)
        my_turtle.left(360/branches)


my_turtle= turtle.Turtle()
branches= 20
length=my_turtle.forward(50)
backup=my_turtle.backward(30)
circle()