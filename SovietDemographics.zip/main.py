'''

Purpose: In this project I will analyze the demographics of Soviet Moldova in the year 1989. The information was retrieved from http://www.demoscope.ru/weekly/ssp/sng_nac_89.php?reg=9
The data will be stored sovietmoldova.csv, and it will be stored in a list.

Additional info in the third column was written by me. I looked up which ethnic people belonged to what ethno-lingusitic group and wrote it in.


I was interested in this project because I was born in Post Soviet Moldova which has went through rapid emigration. 1989 was the peak year in this Soviet Republic's population history, so it's an important year to analyze.

I will answer three questions:
1.) How many people make up 100 percent of the population?
2.) How many Moldovans are there in the Soviet Moldova and how much percent do they make up in their Republic?
3.) How many Slavs are there in Soviet Moldova and how much percent do they make up in the Soviet Republic? 

'''


def FindTotalPopulation():
    ''' Remove the first row of data and find total item from index'''
    del contents_list[0]
    #print(contents_list)
    totalpop= contents_list[0][18:25]
    print('1.)',totalpop,'million people make up 100 percent of the total Soviet Moldova population.')
    

def FindMoldovanPopulation():
    '''Find Moldovan Column. Then print the population with the percent statistic.'''
    totalpop= contents_list[0][18:25]
    Moldovanpop= contents_list[1][10:17]
    #print(Moldovanpop)
    Molpercent= float(Moldovanpop)/float(totalpop)*100
    Molpercent=round(Molpercent)
    print('2.)',Moldovanpop,'million people make up the Moldovan ethnic people at',Molpercent,'percent of the population.')


#3.) How many Slavs are there in Soviet Moldova and how much percent do they make up in their Republic?
#def FindSlavicPopulation():
def FindSlavicPopulation():
    '''Find the total occurance of the Slavic peoples in the csv file. Divide the sum by total people, multiply by 100 and round to find the percent. '''
        
    #find a method that finds the rows with the word 'Slavic'
    count=0
    slavlist=[]
    for items in contents_list:
         items = items.strip().split(',') 
         if items[2] == 'Slavic':
            count+=1
            slavlist.append(int(items[1]))
            #for items in slavlist:
    totalpop= contents_list[0][18:25]               
    slavsum=(sum(slavlist))
    totalslavpercent= (float(slavsum))/(float(totalpop))*100
    roundedslav=round(totalslavpercent)

    print('3.)',slavsum,'million people make up the Slavic population at',roundedslav,'percent of the population.')

#4 Other ethnic population population and percent

def OtherEthnicGroupsPopulation():
    ''' Calculate the rest of the minority population exluding all Moldovans and Slavic peoples(using add and sub skills).'''
    totalpop= contents_list[0][18:25]
    Moldovanpop= contents_list[1][10:17]
    count=0
    slavlist=[]
    for items in contents_list:
         items = items.strip().split(',') 
         if items[2] == 'Slavic':
            count+=1
            slavlist.append(int(items[1]))
            #for items in slavlist:
    totalpop= contents_list[0][18:25]               
    slavsum=(sum(slavlist))
    totalothergroup= int(totalpop)-int(slavsum)-int(Moldovanpop)
    totalotherpercent= float(totalothergroup)/float(totalpop)*100
    #print(totalothergroup)
    #print(round(totalotherpercent))
    print('4.)',totalothergroup,'thousand people make up the other ethnic groups at',round(totalotherpercent),'percent of the population.')



#Opening and closing file with data

file_in= open("sovietmoldova.csv")
contents_list = file_in.readlines()
file_in.close()
#print(contents_list)
#removing commas from csv file

for item in contents_list:
    
    items = item.strip().split(',')
    #print(items)



print()
print("______________________{Soviet Moldova Ethnic Data}_______________________")




print()
FindTotalPopulation()
print()
FindMoldovanPopulation()
print()
FindSlavicPopulation()
print() 
OtherEthnicGroupsPopulation()
print()



print("_____________________________{End of Data}_______________________________")



