def getLetterGrade(grade):
  
  if grade>=90:
    print(grade,'is a A')
  elif  grade>= 80 and grade<90:
    print(grade,'is a B')
  elif grade>= 70 and grade<80:
    print(grade,'is a C')
  elif  grade>= 60 and grade<70:
    print(grade,'is a D')
  else:
    print(grade,'is a F')
    
grade = int(input("Enter a number grade : : "))
getLetterGrade(grade)

grade = int(input("Enter a number grade : : "))
getLetterGrade(grade)

grade = int(input("Enter a number grade : : "))
getLetterGrade(grade)


grade = int(input("Enter a number grade : : "))
getLetterGrade(grade)

grade = int(input("Enter a number grade : : "))
getLetterGrade(grade)



  
