#import random function
import random

#generate random number
def random_num():
  gen_num = random.randint(1,10)
  return gen_num

#prompts user for input between 1 and 10
def guess(random):
  wrong_guess = 0
  guess = 0

  #check if input number is randomly generated
  while guess != random:
    #prompts user to guess a number
    guess = int(input('Guess the number I am thinking of between 1 and 10: '))
    if guess != random:
      #print('Sorry, that was not the number.')
      wrong_guess = wrong_guess + 1
      #print('Wrong guesses:', counter)
    else:
        print('Congratulations, you guessed the secret number', num, 'correctly with', wrong_guess, 'wrong guess(es)!')
        if guess == random:
            print(("Correct!"))
        elif guess < random:
            print("Your guess is too low")
        else:
            print("Your guess is too high")
            return wrong_guess

#creates a random number
num = random_num()

#print('random number is:', num)

wrong_guess = guess(num)
"""
print('Wrong guesses:', wrong_guess)
"""
if guess == random:
    print(("Correct!"))
elif guess < random:
    print("Your guess is too low")
else:
    print("Your guess is too high")
