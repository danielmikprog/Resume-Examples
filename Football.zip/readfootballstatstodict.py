import csv
file_in = open("footballstats.csv")
dict_reader = csv.DictReader(file_in)

#create empty dictionary
quarterback_stats = {}
#read in file contents using Dict Reader object
for row in dict_reader:
    #print(type(row))
    quarterback_stats[row["NAME"]] = {
         "COMP": row["COMP"],
         "TD":  row["TD"],
         "INT": row["INT"]
         
         }

file_in.close()

print(quarterback_stats)


sum_interceptions = 0
for qb in quarterback_stats:
    sum_interceptions += int(quarterback_stats[qb]['INT'])


print('Average interceptions for all quarterbacks = %.2f ' % float(sum_interceptions / len(quarterback_stats)))
