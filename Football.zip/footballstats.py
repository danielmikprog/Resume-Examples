quarterback_stats = {
    'Aaron Rodgers': {'COMP': 371, 'YDS': 4925, 'TD': 39, 'INT': 8},
    'Peyton Manning': {'COMP': 400, 'YDS': 4659, 'TD': 37, 'INT': 11},
    'Greg McElroy': {'COMP': 19, 'YDS': 214, 'TD': 1, 'INT': 1},
    'Matt Leinart': {'COMP': 16, 'YDS': 115, 'TD': 0, 'INT': 1}
}

# for each quarterback in the dictionary print the completions
for quarterback in quarterback_stats:
    comp = quarterback_stats[quarterback]['COMP']
    print(' %15s : %d' % (quarterback, comp) )

print()
print()

for quarterback in quarterback_stats:
    comp = quarterback_stats[quarterback]['YDS']
    print(' %15s : %d' % (quarterback, comp) )

