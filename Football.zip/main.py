
import readfootballstatstodict
#import readfootballstatstolist

'''
print("\n\n\n")
#create a dictionary to translate from english
# to spanish
translation = { } #creating empty dictionary
#hello --> hola
translation['hello']='hola'
#good --> bueno
translation['good']='bueno'
#onion --> cebolla
translation['onion']='cebolla'
#hot --> caliente
translation['hot']='caliente'

# what is the data type for translation, expected dictionary
print(type(translation))
# print the dictionary
print(translation)

#use a for loop to cycle through keys 
print('\nKEYS')
for key in translation.keys():
    #no contains method for string
    if "ot" in key:
        print('CALIENTE')
    print(key)


print('\nVALUES')
#use a for loop to cycle through values
for value in translation.values():
    print(value)

#del hot from
del translation['hot']

#print, notice hot-caliente key-value pair is deleted
print(translation)

'''
