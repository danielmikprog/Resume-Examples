file_in=open('footballstats.csv')
#reads file into list
contents = file_in.readlines()
#done reading file, okay to close
file_in.close()

# debug - look at list that was read in, everything looks okay?
#print(contents)
#delete the first string in the list named contents
#since we are not interested in the column text headers
del contents[0]
# debug - check for deletion, everything looks okay?
#print(contents)

#find the average interceptions for this set of quarterbacks
sum_interceptions = 0;
#for each string of text in the list contents
for line in contents:
    # split string of text into a list of items
    # name,completion,passing yards, touchdowns, interceptions
    items = line.strip().split(',')
    # sum of the 4th item which is the number of interceptions
    # use int to turn the string interceptions number into an integer 
    sum_interceptions+=int(items[4])

print(sum_interceptions/len(contents))